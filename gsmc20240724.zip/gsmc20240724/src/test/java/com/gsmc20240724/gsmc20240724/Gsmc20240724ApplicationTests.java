package com.gsmc20240724.gsmc20240724;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Gsmc20240724ApplicationTests {

	@Test
	void contextLoads() {
	}

}
