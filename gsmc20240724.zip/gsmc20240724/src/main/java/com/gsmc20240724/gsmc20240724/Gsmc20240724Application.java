package com.gsmc20240724.gsmc20240724;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Gsmc20240724Application {

	public static void main(String[] args) {
		SpringApplication.run(Gsmc20240724Application.class, args);
	}

}
